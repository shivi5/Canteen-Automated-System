from tkinter import*
from PIL import Image,ImageTk
import random
import time
master=Tk()
import smtplib
master.geometry("1000x400")
master.title("Canteen Automated System")

lbl = Label(master, font=( 'aria' ,30, 'bold' ),text="CANTEEN AUTOMATED SYSTEM",fg="black",bd=10,anchor='w',relief=SUNKEN)
lbl.grid(row=0,column=20)

lbl = Label(master, font=( 'aria' ,15, 'bold' ),text="Please Enter Your Username and Password to order food ",fg="black",bd=10,anchor='w',relief=SUNKEN)
lbl.grid(row=5,column=20)

#Label(master,text="Username").grid(row=0)
#Label(master,text="password").grid(row=1)
#e1=Entry(master)#
#e2=Entry(master)
#e1.grid(row=0,column=1)
#e2.grid(row=1,column=1)
#Button(master,text="Quit",command=master.quit).grid(row=3,column=0,sticky=W,pady=4)
###########################LOGIN PAGE######################################################

#making labels
user=Label(master,text="Username")
password=Label(master,text="Password")

#pack with grids

user.grid(row=15,column=15)
password.grid(row=16,column=15)


#making input with string var variable class

uservalue=StringVar()
passvalue=StringVar()

userentry=Entry(master,textvariable=uservalue)
passentry=Entry(master,textvariable=passvalue)

#pack by grid

userentry.grid(row=15,column=16)
passentry.grid(row=16,column=16)

#button pack in one line
#Button(text="Momo Box", command=getvals).grid()
#Button(text="Bistro", command=getvals).grid()
#Button(text="Dosa Plaza", command=getvals).grid()








############################MOMO BOX###############################################

def abc():
    print(f"{uservalue.get(),passvalue.get()}")

    with open("result.txt","a") as f:
       f.write("List of Students who order food from MOMO BOX \n") 
       f.write(f"{uservalue.get(),passvalue.get()}\n")
      
    master.destroy()

    root = Tk()
    root.geometry("1600x700+0+0")
    root.title(" MOMOBOX ")
    root.configure(background="light blue")
    
    Tops = Frame(root,width = 1600,height=50,relief=SUNKEN)
    Tops.pack(side=TOP)

    f1 = Frame(root,width = 900,height=700,relief=SUNKEN)
    f1.pack(side=LEFT)

    f2 = Frame(root ,width = 400,height=700,relief=SUNKEN)
    f2.pack(side=RIGHT)
    #------------------TIME--------------
    localtime=time.asctime(time.localtime(time.time()))
    #-----------------INFO TOP------------
    lblinfo = Label(Tops, font=( 'aria' ,30, 'bold' ),text="MOMO BOX",fg="black",bd=10,anchor='w',relief=SUNKEN)
    lblinfo.grid(row=0,column=1)
    lblinfo = Label(Tops, font=( 'aria' ,30, ),text=localtime,fg="black",anchor=W)
    lblinfo.grid(row=1,column=1)

    #---------------Calculator------------------
    text_Input = StringVar()
    operator = ""

    def btnclick(numbers):
        global operator
        operator =operator + str(numbers)
        text_Input.set(operator)

    def btnClearDisplay():
        global operator
        operator = ""
        text_Input.set("")

    def btnEqualsInput():
        global operator
        sumup= str(eval(operator))
        text_Input.set(sumup)
        operator = ""

    txtDisplay = Entry(f2,font=('arail', 18, 'bold'), textvariable=text_Input, bd=15, insertwidth=4, bg="light yellow",justify="right")
    txtDisplay.grid(columnspan=4)

    btn7=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="7", bg="steel blue", command=lambda: btnclick(7))
    btn7.grid(row=2,column=0)
    btn8=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="8", bg="steel blue", command=lambda: btnclick(8))
    btn8.grid(row=2,column=1)
    btn9=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="9", bg="steel blue", command=lambda: btnclick(9))
    btn9.grid(row=2,column=2)
    Addition=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="+", bg="steel blue", command=lambda: btnclick("+"))
    Addition.grid(row=2,column=3)

    btn4=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="4", bg="steel blue", command=lambda: btnclick(4))
    btn4.grid(row=3,column=0)
    btn5=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="5", bg="steel blue", command=lambda: btnclick(5))
    btn5.grid(row=3,column=1)
    btn6=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="6", bg="steel blue", command=lambda: btnclick(6))
    btn6.grid(row=3,column=2)
    Subtraction=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="-", bg="steel blue", command=lambda: btnclick("-"))
    Subtraction.grid(row=3,column=3)

    btn1=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="1", bg="steel blue", command=lambda: btnclick(1))
    btn1.grid(row=4,column=0)
    btn2=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="2", bg="steel blue", command=lambda: btnclick(2))
    btn2.grid(row=4,column=1)
    btn3=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="3", bg="steel blue", command=lambda: btnclick(3))
    btn3.grid(row=4,column=2)
    Multiply=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="*", bg="steel blue", command=lambda: btnclick("*"))
    Multiply.grid(row=4,column=3)

    btn0=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="0", bg="steel blue", command=lambda: btnclick(0))
    btn0.grid(row=5,column=0)
    btnClear=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="C", bg="steel blue", command=btnClearDisplay)
    btnClear.grid(row=5,column=1)
    btnEquals=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="=", bg="steel blue", command=btnEqualsInput)
    btnEquals.grid(row=5,column=2)
    Division=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="/", bg="steel blue", command=lambda: btnclick("/"))
    Division.grid(row=5,column=3)
    status = Label(f2,font=('aria', 15, 'bold'),width = 16, text="-By Team URM",bd=2,relief=SUNKEN)
    status.grid(row=7,columnspan=3)
   

    def Ref():
        x=random.randint(12980, 50876)
        randomRef = str(x)
        rand.set(randomRef)

        cof =float(Fries.get())
        colfries= float(Largefries.get())
        cob= float(Burger.get())
        cofi= float(Filet.get())
        cochee= float(Cheese_burger.get())
        codr= float(Drinks.get())

        costoffries = cof*25
        costoflargefries = colfries*40
        costofburger = cob*35
        costoffilet = cofi*50
        costofcheeseburger = cochee*50
        costofdrinks = codr*35


        costofmeal = "Rs.",str('%.2f'% (costoffries +  costoflargefries + costofburger + costoffilet + costofcheeseburger + costofdrinks))
        PayTax=((costoffries +  costoflargefries + costofburger + costoffilet +  costofcheeseburger + costofdrinks)*0.33)
        Totalcost=(costoffries +  costoflargefries + costofburger + costoffilet  + costofcheeseburger + costofdrinks)
        Ser_Charge=((costoffries +  costoflargefries + costofburger + costoffilet + costofcheeseburger + costofdrinks)/99)
        Service="Rs.",str('%.2f'% Ser_Charge)
        OverAllCost="Rs.",str("%.2f"%( PayTax + Totalcost + Ser_Charge))
        PaidTax="Rs.",str('%.2f'% PayTax)

        Service_Charge.set(Service)
        cost.set(costofmeal)
        Tax.set(PaidTax)
        Subtotal.set(costofmeal)
        Total.set(OverAllCost)
        with open("momo.txt","a") as f:
            f.write("MOMO BOX : Fries,Largefries, Burger, Filet,Cheese Burger,Drinks \n") 
            f.write(f"\t\t{Fries.get(),Largefries.get(),Burger.get(),Filet.get(),Cheese_burger.get(),Drinks.get()}\n")



    def qexit():
        root.destroy()

    def reset():
        rand.set("0")
        Fries.set("0")
        Largefries.set("0")
        Burger.set("0")
        Filet.set("0")
        Subtotal.set("")
        Total.set("0")
        Service_Charge.set("0")
        Drinks.set("0")
        Tax.set("0")
        cost.set("0")
        Cheese_burger.set("0")

    def OrderReceipt():
        a=smtplib.SMTP("smtp.gmail.com",587)
        a.starttls()
        a.login("jyoti785001@gmail.com","baruah007") 
        msg="Order Confirmed for\nCustomerName %s"%(txtCustomer_name.get()) 
        a.sendmail("jyoti785001@gmail.com",txtCustomer_id.get(),msg)
        a.quit()

    

    #---------------------------------------------------------------------------------------
    rand = StringVar()
    Fries = IntVar()
    Largefries = IntVar()
    Burger = IntVar()
    Filet = IntVar()
    Subtotal = StringVar()
    Total = IntVar()
    Service_Charge = StringVar()
    Drinks = IntVar()
    Tax = StringVar()
    cost = IntVar()
    Cheese_burger = IntVar()
    Customer_name = StringVar()
    Customer_id = StringVar()

    lblreference = Label(f1, font=( 'aria' ,16, 'bold' ),text="Order No.",fg="steel blue",bd=10,anchor='w')
    lblreference.grid(row=0,column=0)
    txtreference  = Entry(f1,font=('ariel' ,16,'bold'), textvariable=rand , bd=6,insertwidth=4,bg="powder blue" ,justify='right')
    txtreference.grid(row=0,column=1)

    lblfries = Label(f1, font=( 'aria' ,16, 'bold' ),text="Fries Meal",fg="steel blue",bd=10,anchor='w')
    lblfries.grid(row=1,column=0)
    txtfries = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Fries , bd=6,insertwidth=4,bg="powder blue" ,justify='right')
    txtfries.grid(row=1,column=1)

    lblLargefries = Label(f1, font=( 'aria' ,16, 'bold' ),text="Lunch Meal",fg="steel blue",bd=10,anchor='w')
    lblLargefries.grid(row=2,column=0)
    txtLargefries = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Largefries , bd=6,insertwidth=4,bg="powder blue" ,justify='right')
    txtLargefries.grid(row=2,column=1)


    lblburger = Label(f1, font=( 'aria' ,16, 'bold' ),text="Burger Meal",fg="steel blue",bd=10,anchor='w')
    lblburger.grid(row=3,column=0)
    txtburger = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Burger , bd=6,insertwidth=4,bg="powder blue" ,justify='right')
    txtburger.grid(row=3,column=1)

    lblFilet = Label(f1, font=( 'aria' ,16, 'bold' ),text="Pizza Meal",fg="steel blue",bd=10,anchor='w')
    lblFilet.grid(row=4,column=0)
    txtFilet = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Filet , bd=6,insertwidth=4,bg="powder blue" ,justify='right')
    txtFilet.grid(row=4,column=1)

    lblCheese_burger = Label(f1, font=( 'aria' ,16, 'bold' ),text="Cheese burger",fg="steel blue",bd=10,anchor='w')
    lblCheese_burger.grid(row=5,column=0)
    txtCheese_burger = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Cheese_burger , bd=6,insertwidth=4,bg="powder blue" ,justify='right')
    txtCheese_burger.grid(row=5,column=1)

    lblCustomer_name = Label(f1, font=( 'aria' ,16, 'bold' ),text="Customer name",fg="steel blue",bd=10,anchor='w')
    lblCustomer_name.grid(row=6,column=0)
    txtCustomer_name = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Customer_name , bd=6,insertwidth=4,bg="powder blue" ,justify='right')
    txtCustomer_name.grid(row=6,column=1)
    #--------------------------------------------------------------------------------------
    lblDrinks = Label(f1, font=( 'aria' ,16, 'bold' ),text="Drinks",fg="steel blue",bd=10,anchor='w')
    lblDrinks.grid(row=0,column=2)
    txtDrinks = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Drinks , bd=6,insertwidth=4,bg="powder blue" ,justify='right')
    txtDrinks.grid(row=0,column=3)

    lblcost = Label(f1, font=( 'aria' ,16, 'bold' ),text="cost",fg="steel blue",bd=10,anchor='w')
    lblcost.grid(row=1,column=2)
    txtcost = Entry(f1,font=('ariel' ,16,'bold'), textvariable=cost , bd=6,insertwidth=4,bg="powder blue" ,justify='right')
    txtcost.grid(row=1,column=3)

    lblService_Charge = Label(f1, font=( 'aria' ,16, 'bold' ),text="Service Charge",fg="steel blue",bd=10,anchor='w')
    lblService_Charge.grid(row=2,column=2)
    txtService_Charge = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Service_Charge , bd=6,insertwidth=4,bg="powder blue" ,justify='right')
    txtService_Charge.grid(row=2,column=3)

    lblTax = Label(f1, font=( 'aria' ,16, 'bold' ),text="Tax",fg="steel blue",bd=10,anchor='w')
    lblTax.grid(row=3,column=2)
    txtTax = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Tax , bd=6,insertwidth=4,bg="powder blue" ,justify='right')
    txtTax.grid(row=3,column=3)

    lblSubtotal = Label(f1, font=( 'aria' ,16, 'bold' ),text="Subtotal",fg="steel blue",bd=10,anchor='w')
    lblSubtotal.grid(row=4,column=2)
    txtSubtotal = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Subtotal , bd=6,insertwidth=4,bg="powder blue" ,justify='right')
    txtSubtotal.grid(row=4,column=3)

    lblTotal = Label(f1, font=( 'aria' ,16, 'bold' ),text="Total",fg="steel blue",bd=10,anchor='w')
    lblTotal.grid(row=5,column=2)
    txtTotal = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Total , bd=6,insertwidth=4,bg="powder blue" ,justify='right')
    txtTotal.grid(row=5,column=3)

    lblCustomer_id = Label(f1, font=( 'aria' ,16, 'bold' ),text="Customer_id ",fg="steel blue",bd=10,anchor='w')
    lblCustomer_id .grid(row=6,column=2)
    txtCustomer_id  = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Customer_id , bd=6,insertwidth=4,bg="powder blue" ,justify='right')
    txtCustomer_id .grid(row=6,column=3)


    #-----------------------------------------buttons------------------------------------------
    lblTotal = Label(f1,text="---------------------",fg="white")
    lblTotal.grid(row=7,columnspan=5)

    btnTotal=Button(f1,padx=16,pady=8, bd=10 ,fg="black",font=('ariel' ,16,'bold'),width=10, text="TOTAL", bg="powder blue",command=Ref)
    btnTotal.grid(row=7, column=0)

    btnreset=Button(f1,padx=16,pady=8, bd=10 ,fg="black",font=('ariel' ,16,'bold'),width=10, text="RESET", bg="powder blue",command=reset)
    btnreset.grid(row=7, column=1)

    btnexit=Button(f1,padx=16,pady=8, bd=10 ,fg="black",font=('ariel' ,16,'bold'),width=10, text="EXIT", bg="powder blue",command=qexit)
    btnexit.grid(row=7, column=2)

    btnOrderReceipt=Button(f1,padx=16,pady=8,bd=8,fg="black",font=('areil',16,'bold'),width=10,text="OrderReceipt",bg="powder blue",command=OrderReceipt).grid(row=7,column=3)

    btnprice=Button(f1,padx=16,pady=8, bd=10 ,fg="black",font=('ariel' ,16,'bold'),width=10, text="PRICE", bg="powder blue",command=pricess)
    btnprice.grid(row=7, column=4)

def pricess():
        roo = Tk()
        roo.geometry("600x220+0+0")
        roo.title("Price List")
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="ITEM", fg="black", bd=5)
        lblinfo.grid(row=0, column=0)
        lblinfo = Label(roo, font=('aria', 15,'bold'), text="_____________", fg="white", anchor=W)
        lblinfo.grid(row=0, column=2)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="PRICE", fg="black", anchor=W)
        lblinfo.grid(row=0, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="Fries Meal", fg="steel blue", anchor=W)
        lblinfo.grid(row=1, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="25", fg="steel blue", anchor=W)
        lblinfo.grid(row=1, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="Lunch Meal", fg="steel blue", anchor=W)
        lblinfo.grid(row=2, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="40", fg="steel blue", anchor=W)
        lblinfo.grid(row=2, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="Burger Meal", fg="steel blue", anchor=W)
        lblinfo.grid(row=3, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="35", fg="steel blue", anchor=W)
        lblinfo.grid(row=3, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="Pizza Meal", fg="steel blue", anchor=W)
        lblinfo.grid(row=4, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="50", fg="steel blue", anchor=W)
        lblinfo.grid(row=4, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="Cheese Burger", fg="steel blue", anchor=W)
        lblinfo.grid(row=5, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="30", fg="steel blue", anchor=W)
        lblinfo.grid(row=5, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="Drinks", fg="steel blue", anchor=W)
        lblinfo.grid(row=6, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="35", fg="steel blue", anchor=W)
        lblinfo.grid(row=6, column=3)

def Login():
    if (e1.get()=="user" and e2.get()== "user"):
        master.destroy()
        abc()
    else:
        Label(master,text="**invalid user name or password").grid(row=4)





##################################################################BISTRO LOGIC#############################
def abcd():
    print("List of Students who order food from Bistro Logix \n")
    print(f"{uservalue.get(),passvalue.get()}")
    with open("record.txt","a") as f:
        f.write("List of Students who order food from Bistro Logix \n")
        f.write(f"{uservalue.get(),passvalue.get()}\n")

    
    master.destroy()

    roots = Tk()
    roots.geometry("1600x700+0+0")
    roots.title(" Bistro Logix ")
    roots.configure(background="peachpuff")

    
    Tops = Frame(roots,width = 1600,height=50,relief=SUNKEN)
    Tops.pack(side=TOP)

    f1 = Frame(roots,width = 900,height=700,relief=SUNKEN)
    f1.pack(side=LEFT)

    f2 = Frame(roots ,width = 400,height=700,relief=SUNKEN)
    f2.pack(side=RIGHT)
    #------------------TIME--------------
    localtime=time.asctime(time.localtime(time.time()))
    #-----------------INFO TOP------------
    lblinfo = Label(Tops, font=( 'aria' ,30, 'bold' ),text="BISTRO LOGIX",fg="black",bd=10,anchor='w',relief=SUNKEN)
    lblinfo.grid(row=0,column=1)
    lblinfo = Label(Tops, font=( 'aria' ,30, ),text=localtime,fg="black",anchor=W)
    lblinfo.grid(row=1,column=1)

    #---------------Calculator------------------
    text_Input = StringVar()
    operator = ""

    def btnclick(numbers):
        global operator
        operator =operator + str(numbers)
        text_Input.set(operator)

    def btnClearDisplay():
        global operator
        operator = ""
        text_Input.set("")

    def btnEqualsInput():
        global operator
        sumup= str(eval(operator))
        text_Input.set(sumup)
        operator = ""

    txtDisplay = Entry(f2,font=('arail', 18, 'bold'), textvariable=text_Input, bd=15, insertwidth=4, bg="light yellow",justify="right")
    txtDisplay.grid(columnspan=4)

    btn7=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="7", bg="LIGHTCORAL", command=lambda: btnclick(7))
    btn7.grid(row=2,column=0)
    btn8=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="8", bg="LIGHTCORAL", command=lambda: btnclick(8))
    btn8.grid(row=2,column=1)
    btn9=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="9", bg="LIGHTCORAL", command=lambda: btnclick(9))
    btn9.grid(row=2,column=2)
    Addition=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="+", bg="LIGHTCORAL", command=lambda: btnclick("+"))
    Addition.grid(row=2,column=3)

    btn4=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="4", bg="LIGHTCORAL", command=lambda: btnclick(4))
    btn4.grid(row=3,column=0)
    btn5=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="5", bg="LIGHTCORAL", command=lambda: btnclick(5))
    btn5.grid(row=3,column=1)
    btn6=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="6", bg="LIGHTCORAL", command=lambda: btnclick(6))
    btn6.grid(row=3,column=2)
    Subtraction=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="-", bg="LIGHTCORAL", command=lambda: btnclick("-"))
    Subtraction.grid(row=3,column=3)

    btn1=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="1", bg="LIGHTCORAL", command=lambda: btnclick(1))
    btn1.grid(row=4,column=0)
    btn2=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="2", bg="LIGHTCORAL", command=lambda: btnclick(2))
    btn2.grid(row=4,column=1)
    btn3=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="3", bg="LIGHTCORAL", command=lambda: btnclick(3))
    btn3.grid(row=4,column=2)
    Multiply=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="*", bg="LIGHTCORAL", command=lambda: btnclick("*"))
    Multiply.grid(row=4,column=3)

    btn0=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="0", bg="LIGHTCORAL", command=lambda: btnclick(0))
    btn0.grid(row=5,column=0)
    btnClear=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="C", bg="LIGHTCORAL", command=btnClearDisplay)
    btnClear.grid(row=5,column=1)
    btnEquals=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="=", bg="LIGHTCORAL", command=btnEqualsInput)
    btnEquals.grid(row=5,column=2)
    Division=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="/", bg="LIGHTCORAL", command=lambda: btnclick("/"))
    Division.grid(row=5,column=3)
    status = Label(f2,font=('aria', 15, 'bold'),width = 16, text="-By Team URM",bd=2,relief=SUNKEN)
    status.grid(row=7,columnspan=3)
   

    def Ref():
        x=random.randint(12980, 50876)
        randomRef = str(x)
        rand.set(randomRef)

        cof =float(Fries.get())
        colfries= float(Largefries.get())
        cob= float(Burger.get())
        cofi= float(Filet.get())
        cochee= float(Cheese_burger.get())
        codr= float(Drinks.get())

        costoffries = cof*25
        costoflargefries = colfries*40
        costofburger = cob*35
        costoffilet = cofi*50
        costofcheeseburger = cochee*50
        costofdrinks = codr*35


        costofmeal = "Rs.",str('%.2f'% (costoffries +  costoflargefries + costofburger + costoffilet + costofcheeseburger + costofdrinks))
        PayTax=((costoffries +  costoflargefries + costofburger + costoffilet +  costofcheeseburger + costofdrinks)*0.33)
        Totalcost=(costoffries +  costoflargefries + costofburger + costoffilet  + costofcheeseburger + costofdrinks)
        Ser_Charge=((costoffries +  costoflargefries + costofburger + costoffilet + costofcheeseburger + costofdrinks)/99)
        Service="Rs.",str('%.2f'% Ser_Charge)
        OverAllCost="Rs.",str("%.2f"%( PayTax + Totalcost + Ser_Charge))
        PaidTax="Rs.",str('%.2f'% PayTax)

        Service_Charge.set(Service)
        cost.set(costofmeal)
        Tax.set(PaidTax)
        Subtotal.set(costofmeal)
        Total.set(OverAllCost)

        with open("bistro.txt","a") as f:
            f.write("BISTRO LOGIX : Desi Tea,Cappuccino,Virgin Mojito,Cafe Mocha,Lemon Ice Tea,Ice Cofee \n") 
            f.write(f"\t\t{Fries.get(),Largefries.get(),Burger.get(),Filet.get(),Cheese_burger.get(),Drinks.get()}\n")



    def qexit():
        root.destroy()

    def reset():
        rand.set("0")
        Fries.set("0")
        Largefries.set("0")
        Burger.set("0")
        Filet.set("0")
        Subtotal.set("")
        Total.set("0")
        Service_Charge.set("0")
        Drinks.set("0")
        Tax.set("0")
        cost.set("0")
        Cheese_burger.set("0")

    def OrderReceipt():
        a=smtplib.SMTP("smtp.gmail.com",587)
        a.starttls()
        a.login("jyoti785001@gmail.com","baruah007") 
        msg="Order Confirmed for\nCustomerName %s"%(txtCustomer_name.get()) 
        a.sendmail("jyoti785001@gmail.com",txtCustomer_id.get(),msg)
        a.quit()

    

    #---------------------------------------------------------------------------------------
    rand = StringVar()
    Fries = IntVar()
    Largefries = IntVar()
    Burger = IntVar()
    Filet = IntVar()
    Subtotal = StringVar()
    Total = IntVar()
    Service_Charge = StringVar()
    Drinks = IntVar()
    Tax = StringVar()
    cost = IntVar()
    Cheese_burger = IntVar()
    Customer_name = StringVar()
    Customer_id = StringVar()

    lblreference = Label(f1, font=( 'aria' ,16, 'bold' ),text="Order No.",fg="steel blue",bd=10,anchor='w')
    lblreference.grid(row=0,column=0)
    txtreference  = Entry(f1,font=('ariel' ,16,'bold'), textvariable=rand , bd=6,insertwidth=4,bg="peachpuff" ,justify='right')
    txtreference.grid(row=0,column=1)

    lblfries = Label(f1, font=( 'aria' ,16, 'bold' ),text="Desi Tea",fg="steel blue",bd=10,anchor='w')
    lblfries.grid(row=1,column=0)
    txtfries = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Fries , bd=6,insertwidth=4,bg="peachpuff" ,justify='right')
    txtfries.grid(row=1,column=1)

    lblLargefries = Label(f1, font=( 'aria' ,16, 'bold' ),text="cappuccino",fg="steel blue",bd=10,anchor='w')
    lblLargefries.grid(row=2,column=0)
    txtLargefries = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Largefries , bd=6,insertwidth=4,bg="peachpuff" ,justify='right')
    txtLargefries.grid(row=2,column=1)


    lblburger = Label(f1, font=( 'aria' ,16, 'bold' ),text="Virgin Mojito",fg="steel blue",bd=10,anchor='w')
    lblburger.grid(row=3,column=0)
    txtburger = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Burger , bd=6,insertwidth=4,bg="peachpuff" ,justify='right')
    txtburger.grid(row=3,column=1)

    lblFilet = Label(f1, font=( 'aria' ,16, 'bold' ),text="Cafe Mocha",fg="steel blue",bd=10,anchor='w')
    lblFilet.grid(row=4,column=0)
    txtFilet = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Filet , bd=6,insertwidth=4,bg="peachpuff" ,justify='right')
    txtFilet.grid(row=4,column=1)

    lblCheese_burger = Label(f1, font=( 'aria' ,16, 'bold' ),text="Lemon Ice Tea",fg="steel blue",bd=10,anchor='w')
    lblCheese_burger.grid(row=5,column=0)
    txtCheese_burger = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Cheese_burger , bd=6,insertwidth=4,bg="peachpuff" ,justify='right')
    txtCheese_burger.grid(row=5,column=1)

    lblCustomer_name = Label(f1, font=( 'aria' ,16, 'bold' ),text="Customer name",fg="steel blue",bd=10,anchor='w')
    lblCustomer_name.grid(row=6,column=0)
    txtCustomer_name = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Customer_name , bd=6,insertwidth=4,bg="peachpuff" ,justify='right')
    txtCustomer_name.grid(row=6,column=1)
    #--------------------------------------------------------------------------------------
    lblDrinks = Label(f1, font=( 'aria' ,16, 'bold' ),text="Ice Cofee",fg="steel blue",bd=10,anchor='w')
    lblDrinks.grid(row=0,column=2)
    txtDrinks = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Drinks , bd=6,insertwidth=4,bg="peachpuff" ,justify='right')
    txtDrinks.grid(row=0,column=3)

    lblcost = Label(f1, font=( 'aria' ,16, 'bold' ),text="cost",fg="steel blue",bd=10,anchor='w')
    lblcost.grid(row=1,column=2)
    txtcost = Entry(f1,font=('ariel' ,16,'bold'), textvariable=cost , bd=6,insertwidth=4,bg="peachpuff" ,justify='right')
    txtcost.grid(row=1,column=3)

    lblService_Charge = Label(f1, font=( 'aria' ,16, 'bold' ),text="Service Charge",fg="steel blue",bd=10,anchor='w')
    lblService_Charge.grid(row=2,column=2)
    txtService_Charge = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Service_Charge , bd=6,insertwidth=4,bg="peachpuff" ,justify='right')
    txtService_Charge.grid(row=2,column=3)

    lblTax = Label(f1, font=( 'aria' ,16, 'bold' ),text="Tax",fg="steel blue",bd=10,anchor='w')
    lblTax.grid(row=3,column=2)
    txtTax = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Tax , bd=6,insertwidth=4,bg="peachpuff" ,justify='right')
    txtTax.grid(row=3,column=3)

    lblSubtotal = Label(f1, font=( 'aria' ,16, 'bold' ),text="Subtotal",fg="steel blue",bd=10,anchor='w')
    lblSubtotal.grid(row=4,column=2)
    txtSubtotal = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Subtotal , bd=6,insertwidth=4,bg="peachpuff" ,justify='right')
    txtSubtotal.grid(row=4,column=3)

    lblTotal = Label(f1, font=( 'aria' ,16, 'bold' ),text="Total",fg="steel blue",bd=10,anchor='w')
    lblTotal.grid(row=5,column=2)
    txtTotal = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Total , bd=6,insertwidth=4,bg="peachpuff" ,justify='right')
    txtTotal.grid(row=5,column=3)

    lblCustomer_id = Label(f1, font=( 'aria' ,16, 'bold' ),text="Customer_id ",fg="steel blue",bd=10,anchor='w')
    lblCustomer_id .grid(row=6,column=2)
    txtCustomer_id  = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Customer_id , bd=6,insertwidth=4,bg="peachpuff" ,justify='right')
    txtCustomer_id .grid(row=6,column=3)


    #-----------------------------------------buttons------------------------------------------
    lblTotal = Label(f1,text="---------------------",fg="white")
    lblTotal.grid(row=7,columnspan=5)

    btnTotal=Button(f1,padx=16,pady=8, bd=10 ,fg="black",font=('ariel' ,16,'bold'),width=10, text="TOTAL", bg="peachpuff",command=Ref)
    btnTotal.grid(row=7, column=0)

    btnreset=Button(f1,padx=16,pady=8, bd=10 ,fg="black",font=('ariel' ,16,'bold'),width=10, text="RESET", bg="peachpuff",command=reset)
    btnreset.grid(row=7, column=1)

    btnexit=Button(f1,padx=16,pady=8, bd=10 ,fg="black",font=('ariel' ,16,'bold'),width=10, text="EXIT", bg="peachpuff",command=qexit)
    btnexit.grid(row=7, column=2)

    btnOrderReceipt=Button(f1,padx=16,pady=8,bd=8,fg="black",font=('areil',16,'bold'),width=10,text="OrderReceipt",bg="peachpuff",command=OrderReceipt).grid(row=7,column=3)

    btnprice=Button(f1,padx=16,pady=8, bd=10 ,fg="black",font=('ariel' ,16,'bold'),width=10, text="PRICE", bg="peachpuff",command=pricee)
    btnprice.grid(row=7, column=4)

def pricee():

        roo = Tk()
        roo.geometry("600x220+0+0")
        roo.title("Price List")
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="ITEM", fg="black", bd=5)
        lblinfo.grid(row=0, column=0)
        lblinfo = Label(roo, font=('aria', 15,'bold'), text="_____________", fg="white", anchor=W)
        lblinfo.grid(row=0, column=2)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="PRICE", fg="black", anchor=W)
        lblinfo.grid(row=0, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text=" Tea", fg="steel blue", anchor=W)
        lblinfo.grid(row=1, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="25", fg="steel blue", anchor=W)
        lblinfo.grid(row=1, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="cappuccino", fg="steel blue", anchor=W)
        lblinfo.grid(row=2, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="40", fg="steel blue", anchor=W)
        lblinfo.grid(row=2, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="Virgin Mojito", fg="steel blue", anchor=W)
        lblinfo.grid(row=3, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="35", fg="steel blue", anchor=W)
        lblinfo.grid(row=3, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="Cafe Mocha", fg="steel blue", anchor=W)
        lblinfo.grid(row=4, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="50", fg="steel blue", anchor=W)
        lblinfo.grid(row=4, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="Lemon Ice Tea", fg="steel blue", anchor=W)
        lblinfo.grid(row=5, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="30", fg="steel blue", anchor=W)
        lblinfo.grid(row=5, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="Ice Coffe", fg="steel blue", anchor=W)
        lblinfo.grid(row=6, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="35", fg="steel blue", anchor=W)
        lblinfo.grid(row=6, column=3)


####################################################################DOSA PLAZA###########################################
def abcde():
    print(f"{uservalue.get(),passvalue.get()}")
    with open("record.txt","a") as f:
        f.write("List of Students who order food from Dosa Plaza \n")
        f.write(f"{uservalue.get(),passvalue.get()}\n")

    master.destroy()
        

    rootss = Tk()
    rootss.geometry("1600x700+0+0")
    rootss.configure(background="cyan")

    rootss.title(" DOSA PLAZA ")
                
    Tops = Frame(rootss,width = 1600,height=50,relief=SUNKEN)
    Tops.pack(side=TOP)

    f1 = Frame(rootss,width = 900,height=700,relief=SUNKEN)
    f1.pack(side=LEFT)

    f2 = Frame(rootss ,width = 400,height=700,relief=SUNKEN)
    f2.pack(side=RIGHT)
             #------------------TIME--------------
    localtime=time.asctime(time.localtime(time.time()))
               #-----------------INFO TOP------------
    lblinfo = Label(Tops, font=( 'aria' ,30, 'bold' ),text="DOSA PLAZA",fg="black",bd=10,anchor='w',relief=SUNKEN)
    lblinfo.grid(row=0,column=1)
    lblinfo = Label(Tops, font=( 'aria' ,30, ),text=localtime,fg="black",anchor=W)
    lblinfo.grid(row=1,column=1)

               #---------------Calculator------------------
    text_Input = StringVar()
    operator = ""
    def btnclick(numbers):
        global operator
        operator =operator + str(numbers)
        text_Input.set(operator)

    def btnClearDisplay():
        global operator
        operator = ""
        text_Input.set("")

    def btnEqualsInput():
        global operator
        sumup= str(eval(operator))
        text_Input.set(sumup)
        operator = ""
    txtDisplay = Entry(f2,font=('arail', 18, 'bold'), textvariable=text_Input, bd=15, insertwidth=4, bg="light yellow",justify="right")
    txtDisplay.grid(columnspan=4)

    btn7=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="7", bg="cyan", command=lambda: btnclick(7))
    btn7.grid(row=2,column=0)
    btn8=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="8", bg="cyan", command=lambda: btnclick(8))
    btn8.grid(row=2,column=1)
    btn9=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="9", bg="cyan", command=lambda: btnclick(9))
    btn9.grid(row=2,column=2)
    Addition=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="+", bg="cyan", command=lambda: btnclick("+"))
    Addition.grid(row=2,column=3)

    btn4=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="4", bg="cyan", command=lambda: btnclick(4))
    btn4.grid(row=3,column=0)
    btn5=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="5", bg="cyan", command=lambda: btnclick(5))
    btn5.grid(row=3,column=1)
    btn6=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="6", bg="cyan", command=lambda: btnclick(6))
    btn6.grid(row=3,column=2)
    Subtraction=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="-", bg="cyan", command=lambda: btnclick("-"))
    Subtraction.grid(row=3,column=3)

    btn1=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="1", bg="cyan", command=lambda: btnclick(1))
    btn1.grid(row=4,column=0)
    btn2=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="2", bg="cyan", command=lambda: btnclick(2))
    btn2.grid(row=4,column=1)
    btn3=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="3", bg="cyan", command=lambda: btnclick(3))
    btn3.grid(row=4,column=2)
    Multiply=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="*", bg="cyan", command=lambda: btnclick("*"))
    Multiply.grid(row=4,column=3)

    btn0=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="0", bg="cyan", command=lambda: btnclick(0))
    btn0.grid(row=5,column=0)
    btnClear=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="C", bg="cyan", command=btnClearDisplay)
    btnClear.grid(row=5,column=1)
    btnEquals=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="=", bg="cyan", command=btnEqualsInput)
    btnEquals.grid(row=5,column=2)
    Division=Button(f2,padx=10,pady=10, fg="black", font=('arail',20,'bold'),text="/", bg="cyan", command=lambda: btnclick("/"))
    Division.grid(row=5,column=3)
    status = Label(f2,font=('aria', 15, 'bold'),width = 16, text="-By Team URM",bd=2,relief=SUNKEN)
    status.grid(row=7,columnspan=3)
               

    def Ref():
        x=random.randint(12980, 50876)
        randomRef = str(x)
        rand.set(randomRef)

        cof =float(Fries.get())
        colfries= float(Largefries.get())
        cob= float(Burger.get())
        cofi= float(Filet.get())
        cochee= float(Cheese_burger.get())
        codr= float(Drinks.get())

        costoffries = cof*25
        costoflargefries = colfries*40
        costofburger = cob*35
        costoffilet = cofi*50
        costofcheeseburger = cochee*50
        costofdrinks = codr*35

        costofmeal = "Rs.",str('%.2f'% (costoffries +  costoflargefries + costofburger + costoffilet + costofcheeseburger + costofdrinks))
        PayTax=((costoffries +  costoflargefries + costofburger + costoffilet +  costofcheeseburger + costofdrinks)*0.33)
        Totalcost=(costoffries +  costoflargefries + costofburger + costoffilet  + costofcheeseburger + costofdrinks)
        Ser_Charge=((costoffries +  costoflargefries + costofburger + costoffilet + costofcheeseburger + costofdrinks)/99)
        Service="Rs.",str('%.2f'% Ser_Charge)
        OverAllCost="Rs.",str("%.2f"%( PayTax + Totalcost + Ser_Charge))
        PaidTax="Rs.",str('%.2f'% PayTax)
        Service_Charge.set(Service)
        cost.set(costofmeal)
        Tax.set(PaidTax)
        Subtotal.set(costofmeal)
        Total.set(OverAllCost)

        with open("dosa.txt","a") as f:
            f.write("DOSA PLAZA : Idli,Rava Dosa,Masala Dosa,South Indian Thali,Poori Bhaji,Drinks\n") 
            f.write(f"\t\t{Fries.get(),Largefries.get(),Burger.get(),Filet.get(),Cheese_burger.get(),Drinks.get()}\n")



    def qexit():
        rootss.destroy()

    def reset():
        rand.set("0")
        Fries.set("0")
        Largefries.set("0")
        Burger.set("0")
        Filet.set("0")
        Subtotal.set("")
        Total.set("0")
        Service_Charge.set("0")
        Drinks.set("0")
        Tax.set("0")
        cost.set("0")
        Cheese_burger.set("0")

    def OrderReceipt():
        
                   
        a=smtplib.SMTP("smtp.gmail.com",587)
        a.starttls()
        a.login("jyoti785001@gmail.com","baruah007") 
        msg="Order Confirmed for\nCustomerName %s"%(txtCustomer_name.get()) 
        a.sendmail("jyoti785001@gmail.com",txtCustomer_id.get(),msg)
        a.quit()

                

                #---------------------------------------------------------------------------------------
    rand = StringVar()
    Fries = IntVar()
    Largefries = IntVar()
    Burger = IntVar()
    Filet = IntVar()
    Subtotal = StringVar()
    Total = IntVar()
    Service_Charge = StringVar()
    Drinks = IntVar()
    Tax = StringVar()
    cost = IntVar()
    Cheese_burger = IntVar()
    Customer_name = StringVar()
    Customer_id = StringVar()

    lblreference = Label(f1, font=( 'aria' ,16, 'bold' ),text="Order No.",fg="steel blue",bd=10,anchor='w')
    lblreference.grid(row=0,column=0)
    txtreference  = Entry(f1,font=('ariel' ,16,'bold'), textvariable=rand , bd=6,insertwidth=4,bg="cyan" ,justify='right')
    txtreference.grid(row=0,column=1)

    lblfries = Label(f1, font=( 'aria' ,16, 'bold' ),text="Idli",fg="steel blue",bd=10,anchor='w')
    lblfries.grid(row=1,column=0)
    txtfries = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Fries , bd=6,insertwidth=4,bg="cyan" ,justify='right')
    txtfries.grid(row=1,column=1)

    lblLargefries = Label(f1, font=( 'aria' ,16, 'bold' ),text="Rava Dosa",fg="steel blue",bd=10,anchor='w')
    lblLargefries.grid(row=2,column=0)
    txtLargefries = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Largefries , bd=6,insertwidth=4,bg="cyan" ,justify='right')
    txtLargefries.grid(row=2,column=1)

    lblburger = Label(f1, font=( 'aria' ,16, 'bold' ),text="Masala Dosa",fg="steel blue",bd=10,anchor='w')
    lblburger.grid(row=3,column=0)
    txtburger = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Burger , bd=6,insertwidth=4,bg="cyan" ,justify='right')
    txtburger.grid(row=3,column=1)

    lblFilet = Label(f1, font=( 'aria' ,16, 'bold' ),text="South Indian Thali",fg="steel blue",bd=10,anchor='w')
    lblFilet.grid(row=4,column=0)
    txtFilet = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Filet , bd=6,insertwidth=4,bg="cyan" ,justify='right')
    txtFilet.grid(row=4,column=1)

    lblCheese_burger = Label(f1, font=( 'aria' ,16, 'bold' ),text="Poori Bhajji",fg="steel blue",bd=10,anchor='w')
    lblCheese_burger.grid(row=5,column=0)
    txtCheese_burger = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Cheese_burger , bd=6,insertwidth=4,bg="cyan" ,justify='right')
    txtCheese_burger.grid(row=5,column=1)

    lblCustomer_name = Label(f1, font=( 'aria' ,16, 'bold' ),text="Customer name",fg="steel blue",bd=10,anchor='w')
    lblCustomer_name.grid(row=6,column=0)
    txtCustomer_name = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Customer_name , bd=6,insertwidth=4,bg="cyan" ,justify='right')
    txtCustomer_name.grid(row=6,column=1)
                #--------------------------------------------------------------------------------------
    lblDrinks = Label(f1, font=( 'aria' ,16, 'bold' ),text="Drinks",fg="steel blue",bd=10,anchor='w')
    lblDrinks.grid(row=0,column=2)
    txtDrinks = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Drinks , bd=6,insertwidth=4,bg="cyan" ,justify='right')
    txtDrinks.grid(row=0,column=3)

    lblcost = Label(f1, font=( 'aria' ,16, 'bold' ),text="cost",fg="steel blue",bd=10,anchor='w')
    lblcost.grid(row=1,column=2)
    txtcost = Entry(f1,font=('ariel' ,16,'bold'), textvariable=cost , bd=6,insertwidth=4,bg="cyan" ,justify='right')
    txtcost.grid(row=1,column=3)

    lblService_Charge = Label(f1, font=( 'aria' ,16, 'bold' ),text="Service Charge",fg="steel blue",bd=10,anchor='w')
    lblService_Charge.grid(row=2,column=2)
    txtService_Charge = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Service_Charge , bd=6,insertwidth=4,bg="cyan" ,justify='right')
    txtService_Charge.grid(row=2,column=3)

    lblTax = Label(f1, font=( 'aria' ,16, 'bold' ),text="Tax",fg="steel blue",bd=10,anchor='w')
    lblTax.grid(row=3,column=2)
    txtTax = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Tax , bd=6,insertwidth=4,bg="cyan" ,justify='right')
    txtTax.grid(row=3,column=3)

    lblSubtotal = Label(f1, font=( 'aria' ,16, 'bold' ),text="Subtotal",fg="steel blue",bd=10,anchor='w')
    lblSubtotal.grid(row=4,column=2)
    txtSubtotal = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Subtotal , bd=6,insertwidth=4,bg="cyan" ,justify='right')
    txtSubtotal.grid(row=4,column=3)

    lblTotal = Label(f1, font=( 'aria' ,16, 'bold' ),text="Total",fg="steel blue",bd=10,anchor='w')
    lblTotal.grid(row=5,column=2)
    txtTotal = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Total , bd=6,insertwidth=4,bg="cyan" ,justify='right')
    txtTotal.grid(row=5,column=3)

    lblCustomer_id = Label(f1, font=( 'aria' ,16, 'bold' ),text="Customer_id ",fg="steel blue",bd=10,anchor='w')
    lblCustomer_id .grid(row=6,column=2)
    txtCustomer_id  = Entry(f1,font=('ariel' ,16,'bold'), textvariable=Customer_id , bd=6,insertwidth=4,bg="cyan" ,justify='right')
    txtCustomer_id .grid(row=6,column=3)


                #-----------------------------------------buttons------------------------------------------
    lblTotal = Label(f1,text="---------------------",fg="white")
    lblTotal.grid(row=7,columnspan=5)

    btnTotal=Button(f1,padx=16,pady=8, bd=10 ,fg="black",font=('ariel' ,16,'bold'),width=10, text="TOTAL", bg="cyan",command=Ref)
    btnTotal.grid(row=7, column=0)

    btnreset=Button(f1,padx=16,pady=8, bd=10 ,fg="black",font=('ariel' ,16,'bold'),width=10, text="RESET", bg="cyan",command=reset)
    btnreset.grid(row=7, column=1)

    btnexit=Button(f1,padx=16,pady=8, bd=10 ,fg="black",font=('ariel' ,16,'bold'),width=10, text="EXIT", bg="cyan",command=qexit)
    btnexit.grid(row=7, column=2)

    btnOrderReceipt=Button(f1,padx=16,pady=8,bd=8,fg="black",font=('areil',16,'bold'),width=10,text="OrderReceipt",bg="cyan",command=OrderReceipt).grid(row=7,column=3)


    btnprice=Button(f1,padx=16,pady=8, bd=10 ,fg="black",font=('ariel' ,16,'bold'),width=10, text="PRICE", bg="cyan",command=price)
    btnprice.grid(row=7, column=4)

        
def price():
        roo = Tk()
        roo.geometry("600x220+0+0")
        roo.title("Price List")
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="ITEM", fg="black", bd=5)
        lblinfo.grid(row=0, column=0)
        lblinfo = Label(roo, font=('aria', 15,'bold'), text="_____________", fg="white", anchor=W)
        lblinfo.grid(row=0, column=2)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="PRICE", fg="black", anchor=W)
        lblinfo.grid(row=0, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="Idli", fg="steel blue", anchor=W)
        lblinfo.grid(row=1, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="25", fg="steel blue", anchor=W)
        lblinfo.grid(row=1, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="Rava Dosa", fg="steel blue", anchor=W)
        lblinfo.grid(row=2, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="40", fg="steel blue", anchor=W)
        lblinfo.grid(row=2, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="Masala Dosa", fg="steel blue", anchor=W)
        lblinfo.grid(row=3, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="35", fg="steel blue", anchor=W)
        lblinfo.grid(row=3, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="South Indian Thali", fg="steel blue", anchor=W)
        lblinfo.grid(row=4, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="50", fg="steel blue", anchor=W)
        lblinfo.grid(row=4, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="Poori Bhaji", fg="steel blue", anchor=W)
        lblinfo.grid(row=5, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="30", fg="steel blue", anchor=W)
        lblinfo.grid(row=5, column=3)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="Drinks", fg="steel blue", anchor=W)
        lblinfo.grid(row=6, column=0)
        lblinfo = Label(roo, font=('aria', 15, 'bold'), text="35", fg="steel blue", anchor=W)
        lblinfo.grid(row=6, column=3)
        
        

##################################################################################################

Button(master,text="MOMO BOX",command=abc).grid(row=17,column=15,sticky=W,pady=5)
Button(master,text="BISTRO",command=abcd).grid(row=17,column=16,sticky=W,pady=6)
Button(master,text="DOSA PLAZA",command=abcde).grid(row=17,column=17,sticky=W,pady=4)




